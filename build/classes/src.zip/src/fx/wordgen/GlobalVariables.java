/*
 To change this license header, choose License Headers in Project Properties.
 To change this template file, choose Tools | Templates
 and open the template in the editor.
 */
package fx.wordgen;

import java.io.File;

/**

 @author Mark Ferguson
 */
public class GlobalVariables {

  static String CRLF = "\n";
  static String FS = File.separator;
  static String T5 = "C:" + FS + "T5";

}
