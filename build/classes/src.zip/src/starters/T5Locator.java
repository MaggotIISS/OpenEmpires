/*
 To change this license header, choose License Headers in Project Properties.
 To change this template file, choose Tools | Templates
 and open the template in the editor.
 */
package starters;

import panels.Panel4T5Locator;

/**
 <p>
 @author Mark Ferguson
 */
public class T5Locator {

  /**
   <p>
   @param args strings to start
   */
  public static void main(String[] args) {
    Panel4T5Locator.main(args);
  }

}
